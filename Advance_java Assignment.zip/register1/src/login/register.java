package login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;



public class register {

	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/STUDENT_REPORT_CARD";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "Pratiksha@123";

	
	
public void createuser(User user) throws Exception
{
	Class.forName(DB_DRIVER);
	try(Connection con=DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);)
	{
	 String sql="INSERT INTO REGISTER(stud_first,stud_last_name,stud_midal_name,Roll_No,password,email_Id,verified_Email_Id) VALUES(?,?,?,?,?,?,?)";
	      PreparedStatement ps=con.prepareStatement(sql);
	      ps.setString(1, user.getStud_first());
	      ps.setString(2,user.getStud_last_name());
	      ps.setString(3,user.getStud_midal_name());
	      ps.setString(4,user.getRoll_No());
	      ps.setString(5,user.getPassword());
	      ps.setString(6,user.getEmail_Id());
	      ps.setString(7,user.getVerified_Email_Id());
	      ps.executeUpdate();
			System.out.println("Insert Success");
	}
	catch(Exception e)
	{
		e.printStackTrace();
		throw e;
	}
	
	

}


public void createuser1(User user) throws Exception
{
	Class.forName(DB_DRIVER);
	try(Connection con=DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);)
	{
	 String sql="INSERT INTO REGISTER(Roll_No,email_Id) VALUES(?,?)";
	      PreparedStatement ps=con.prepareStatement(sql);
	    
	      ps.setString(1,user.getRoll_No());
	    
	      ps.setString(2,user.getEmail_Id());
	   
	      ps.executeUpdate();
			System.out.println("Insert Success");
	}
	catch(Exception e)
	{
		e.printStackTrace();
		throw e;
	}
	
	

}


public boolean deleteUser(User user) throws Exception {
	Class.forName(DB_DRIVER);
	try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);){
	
		String sql = "DELETE FROM REGISTER WHERE email_Id=?";
		PreparedStatement ps =  con.prepareStatement(sql);
		ps.setString(1, user.getEmail_Id());
		
		ps.executeUpdate();
		
		return true;
	} catch (Exception e) {
		e.printStackTrace();
		return false;
	}
}





public List<User> readAllUser() throws Exception {
	Class.forName(DB_DRIVER);
	try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
		String sql = "SELECT * FROM REGISTER";
		PreparedStatement ps =  con.prepareStatement(sql);

		ResultSet rs = ps.executeQuery();
		List<User> list = new ArrayList<User>();
		while(rs.next()) {
			// ROW :: Reading columns of row
			
			
	    	String stud_first1=rs.getString("stud_first");
	    	String stud_last_name1=rs.getString("stud_last_name");
	    	String stud_midal_name1=rs.getString("stud_midal_name");
	    	String roll_no=rs.getString("roll_No");
	    	String password=rs.getString("password");
	    	String email_Id=rs.getString("email_Id");
	    	String verified_Email_Id=rs.getString("verified_Email_Id");
	    	
			

	    	User user=new User();
	    	user.setStud_first(stud_first1);
	    	user.setStud_last_name(stud_last_name1);
	    	user.setStud_midal_name(stud_midal_name1);
	    	user.setEmail_Id(email_Id);
	    	user.setPassword(password);
	    	user.setRoll_No(roll_no);
	    	user.setVerified_Email_Id(verified_Email_Id);
	    	
	    	list.add(user);
		}
		
		return list;
	} catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
}


public static void main(String[] args) throws Exception {
	
		User user=new User("rakesh","samanth","abc","3","ra@123","rakesha@123gmail.com","rakesha@123gmail.com");
		 register reg=new  register();
		// reg.createuser(user);
		 
	User user1=new User("rakesha@123gmail.com");
	//reg.deleteUser(user1);
	
//	User user2=new User("punam@123gmail.com",10);
	//reg.createuser1(user2);
	
	
	
	List<User> list = reg.readAllUser();
	System.out.println(list);
		 
	}

}
