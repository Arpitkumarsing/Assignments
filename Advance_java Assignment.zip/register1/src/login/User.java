package login;

public class User {

	private String stud_first;
	private String stud_last_name;
	private String stud_midal_name;
	private String roll_No;
	private String password;
	private String email_Id;
	private String verified_Email_Id;
	
	
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public User(String email_Id) {
		this.email_Id=email_Id;
	}
	
	public User(String email_Id,String roll_No) {
		this.email_Id=email_Id;
	this.roll_No=roll_No;
	}
	
	public User(String stud_first,String stud_last_name,String stud_midal_name,String roll_No,String password,String email_Id,String verified_Email_Id) {
		this.stud_first=stud_first;
		this.stud_last_name=stud_last_name;
		this.stud_midal_name=stud_midal_name;
		this.roll_No=roll_No;
		this.password=password;
		this.email_Id=email_Id;
		this.verified_Email_Id=verified_Email_Id;
		// TODO Auto-generated constructor stub
	}
	public String getStud_first() {
		return stud_first;
	}
	public void setStud_first(String stud_first) {
		this.stud_first = stud_first;
	}
	public String getStud_last_name() {
		return stud_last_name;
	}
	public void setStud_last_name(String stud_last_name) {
		this.stud_last_name = stud_last_name;
	}
	public String getStud_midal_name() {
		return stud_midal_name;
	}
	public void setStud_midal_name(String stud_midal_name) {
		this.stud_midal_name = stud_midal_name;
	}
	public String getRoll_No() {
		return roll_No;
	}
	public void setRoll_No(String roll_No) {
		this.roll_No = roll_No;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail_Id() {
		return email_Id;
	}
	public void setEmail_Id(String email_Id) {
		this.email_Id = email_Id;
	}
	public String getVerified_Email_Id() {
		return verified_Email_Id;
	}
	public void setVerified_Email_Id(String verified_Email_Id) {
		this.verified_Email_Id = verified_Email_Id;
	}
	
	
	
}
