package controll;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.User;
import login.register;

@WebServlet("/deleteuser")
public class deleteuser extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
	    out.println("hello......................");
	    
	   String email=request.getParameter("email_Id");
	 
	    
	//    int roll=()
	 // int i=Integer.parseInt(rollno);  
	  
	   User user=new User();
	  user.setEmail_Id(email);
	
	   register reg=new  register();
	    
	   try {
			reg.deleteUser(user);
			out.println("sucess.........");
			request.getRequestDispatcher("readuser").forward(request, response);
		} catch (Exception e) {
		
			e.printStackTrace();
			out.println("Error");
		}
	     
	   out.println(email);
	
	    System.out.println("<div style='backgraundcolor:green'>delete sucessfull</div>");
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
