package controll;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.User;
import login.register;

/**
 * Servlet implementation class createUser
 */
@WebServlet(name = "create-user", urlPatterns = { "/create-user" })
public class createUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
	    out.println("hello rakesh and priyanka");
	    
	   String email=request.getParameter("email_Id");
	   String rollno=request.getParameter("roll_No");
	    
	//    int roll=()
	 // int i=Integer.parseInt(rollno);  
	  
	   User user=new User();
	  user.setEmail_Id(email);
	  user.setRoll_No(rollno);
	    
	   register reg=new  register();
	    
	   try {
			reg.createuser1(user);
			out.println("sucess.........");
			request.getRequestDispatcher("readuser").forward(request, response);
		} catch (Exception e) {
		
			e.printStackTrace();
			out.println("Error");
		}
	     
	   out.println(email);
	  out.println(rollno);
	    System.out.println("hello");
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 doGet(request,response);
	}

}
