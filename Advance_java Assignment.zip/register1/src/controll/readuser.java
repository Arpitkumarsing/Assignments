package controll;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import login.User;
import login.register;

/**
 * Servlet implementation class readuser
 */
@WebServlet("/readuser")
public class readuser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out=response.getWriter();
		try {
			register dao = new register();
			
			// we calling dao logic here.
			List<User> userList =  dao.readAllUser();
			
			request.setAttribute("userList", userList);
			System.out.println("hello..............."+userList);
		
			request.getRequestDispatcher("sucess.jsp").forward(request, response);
		
		} catch(Exception e) {
			e.printStackTrace();
			
			// in case of error
			out.println("Error.......................");
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
