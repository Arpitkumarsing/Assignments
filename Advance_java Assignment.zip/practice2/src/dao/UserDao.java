package dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.NativeQuery;

import entity.User;

public class UserDao {
	public static SessionFactory factory = new Configuration().configure().buildSessionFactory();

	public static void main(String[] args) {

//	update();

	}

	public void create(User user) {

		Session session = factory.openSession();
		Transaction tr = session.beginTransaction();

	
		System.out.println("hello");
		session.save(user);

		tr.commit();
		session.close();

	}

	public  List<User> readAll() {

		Session session = factory.openSession();
		// Transaction tr= session.beginTransaction();

		List<User> user = session.createQuery("from User", User.class).list();

		for (User user2 : user) {

			System.out.println(user2.getName() + " " + user2.getEmail());
		}

		session.close();
		return user;

	}

	public  List<User> read1() {
		Session session = factory.openSession();

		List<User> user = session.createQuery("from User where id=9", User.class).list();

		for (User user2 : user) {

			System.out.println(user2.getName() + " " + user2.getEmail());
		}
		session.close();
		
		return user;

	}

	/*
	 * public static void read() { Session session=factory.openSession();
	 * 
	 * String sql="SELECT * FROM User WHERE id=?"; List<User> user =
	 * session.createNamedQuery(sql,User.class).setParameter("id", 1).list();
	 * 
	 * for (User user2 : user) { System.out.println(user2.getId()); }
	 * session.close();
	 * 
	 * 
	 * }
	 */

	
	// update value
	
	/*
	public static void update(int id,String name,String email) {
		
		if(user!=null)
		{
			user.setEmail);
		}
		
		Session session = factory.openSession();
		Transaction tr = session.beginTransaction();

		User u = new User();
		u.setId(29);
		u.setEmail("rajat@gmail.com");
//		u.setName("");

		session.update(u);
		tr.commit();
		session.close();

	}
	
	*/
	
	

	public void  updateUser(User user)
	{
		Session session = factory.openSession();
	Transaction tr=	session.beginTransaction();
		
		String sql="UPDATE User  SET name=:name, email=:email WHERE ID=:id";
		session.createNativeQuery(sql).setParameter("name",user.getName())
				                      .setParameter("email",user.getEmail())				                     
				                   .setParameter("id",user.getId()).executeUpdate();

		System.out.println(user.getEmail());
		System.out.println(user.getName());
	    tr.commit();
		session.close();
	}
	
	
	
	
	public static  void delete(int id) {
		Session session = factory.openSession();
		Transaction tr = session.beginTransaction();

		User u = new User();
		u.setId(id);
	
		session.delete(u);
		System.out.println("delete successfuly");

		
		tr.commit();
		session.close();

	}

	
	
	
}
